<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Renderable and templatable output for the index page.
 *
 * @package    tool_bulkcohortsync
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace tool_bulkcohortsync\output;

defined('MOODLE_INTERNAL') || die();

use renderable;
use templatable;
use renderer_base;
use tool_bulkcohortsync\helper;
use moodle_url;
use core_text;

/**
 * Renderable and templatable class representing the index page.
 *
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class index_page implements renderable, templatable {

    /** @var array Execution logs from form processing. */
    protected $logs;

    /**
     * Constructor.
     *
     * @param array $logs Execution logs.
     */
    public function __construct(array $logs = []) {
        $this->logs = $logs;
    }

    /**
     * Export data for Mustache template.
     *
     * @param renderer_base $output The renderer.
     * @return array Exported data.
     */
    public function export_for_template(renderer_base $output): array {
        global $DB;

        // Categories tree.
        $tree = helper::get_category_tree();
        $categoriestemplate = helper::export_category_tree_for_template($tree);

        // Cohorts.
        $cohorts = $DB->get_records('cohort', null, 'name ASC', 'id, name, idnumber');
        $cohortsdata = [];
        foreach ($cohorts as $coh) {
            $cohortsdata[] = [
                'id' => $coh->id,
                'name' => format_string($coh->name),
                'idnumber' => s($coh->idnumber),
                'searchname' => s(core_text::strtolower($coh->name . ' ' . $coh->idnumber)),
            ];
        }

        // Roles.
        $roles = $DB->get_records('role', null, 'sortorder ASC', 'id, name, shortname');
        $rolesdata = [];
        foreach ($roles as $r) {
            $rolesdata[] = [
                'id' => $r->id,
                'name' => role_get_name($r),
                'shortname' => s($r->shortname),
                'selected' => ($r->shortname === 'student'),
            ];
        }

        // Logs.
        $logsdata = [];
        foreach ($this->logs as $log) {
            $logsdata[] = [
                'type' => s($log['type']),
                'badge' => s(core_text::strtoupper($log['type'])),
                'message' => s($log['message']),
            ];
        }

        return [
            'sesskey' => sesskey(),
            'cohortsyncurl' => (new moodle_url('/admin/tool/bulkcohortsync/index.php'))->out(false),
            'resourcesurl' => (new moodle_url('/admin/tool/bulkcohortsync/bulk_resources.php'))->out(false),
            'haslogs' => !empty($logsdata),
            'logs' => $logsdata,
            'categories' => $categoriestemplate,
            'cohorts' => $cohortsdata,
            'roles' => $rolesdata,
        ];
    }
}
