<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Main page for tool_bulkcohortsync plugin.
 *
 * @package    tool_bulkcohortsync
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');

admin_externalpage_setup('tool_bulkcohortsync');

$logs = [];

// Handle form submission.
if ($data = data_submitted() && confirm_sesskey()) {
    $selectedcourses = optional_param_array('courses', [], PARAM_INT);
    $selectedcohorts = optional_param_array('cohorts', [], PARAM_INT);
    $roleid = required_param('roleid', PARAM_INT);

    if (empty($selectedcourses) || empty($selectedcohorts)) {
        $logs[] = [
            'type' => 'error',
            'message' => get_string('error_selectboth', 'tool_bulkcohortsync'),
        ];
    } else {
        foreach ($selectedcourses as $cid) {
            $course = $DB->get_record('course', ['id' => $cid]);
            if (!$course) {
                continue;
            }

            foreach ($selectedcohorts as $cohid) {
                $cohort = $DB->get_record('cohort', ['id' => $cohid]);
                if (!$cohort) {
                    continue;
                }

                $result = \tool_bulkcohortsync\helper::add_cohort_sync_instance($course, $cohort, $roleid);
                $logs[] = $result;
            }
        }
    }
}

// Load AMD module.
$PAGE->requires->js_call_amd('tool_bulkcohortsync/main', 'init', [
    get_string('selected', 'tool_bulkcohortsync'),
]);

$page = new \tool_bulkcohortsync\output\index_page($logs);
$renderer = $PAGE->get_renderer('tool_bulkcohortsync');

echo $OUTPUT->header();
echo $renderer->render($page);
echo $OUTPUT->footer();
