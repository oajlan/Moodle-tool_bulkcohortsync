<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Bulk course resources upload page for tool_bulkcohortsync plugin.
 *
 * @package    tool_bulkcohortsync
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->dirroot . '/course/modlib.php');
require_once($CFG->dirroot . '/course/lib.php');

admin_externalpage_setup('tool_bulkcohortsync');

$catid = optional_param('catid', 0, PARAM_INT);

// Fetch all categories for the dropdown.
$categories = $DB->get_records('course_categories', null, 'sortorder ASC', 'id, name, parent, depth');

// Fetch courses for the selected category if selected.
$coursesincat = [];
if ($catid > 0) {
    $coursesincat = $DB->get_records_select(
        'course',
        "category = :catid AND format <> 'site'",
        ['catid' => $catid],
        'fullname ASC',
        'id, fullname, shortname'
    );
}

$logs = [];
$mform = null;

if ($catid > 0 && !empty($coursesincat)) {
    $formurl = new moodle_url('/admin/tool/bulkcohortsync/bulk_resources.php', ['catid' => $catid]);
    $mform = new \tool_bulkcohortsync\form\bulk_resources_form($formurl, [
        'courses' => $coursesincat,
        'catid' => $catid,
    ]);

    if ($mform->is_cancelled()) {
        redirect(new moodle_url('/admin/tool/bulkcohortsync/bulk_resources.php'));
    } else if ($data = $mform->get_data()) {
        $modresource = $DB->get_record('modules', ['name' => 'resource']);
        $modurl = $DB->get_record('modules', ['name' => 'url']);
        $fs = get_file_storage();
        $usercontext = context_user::instance($USER->id);

        foreach ($coursesincat as $c) {
            $cid = $c->id;
            $coursecontext = context_course::instance($cid);

            // Check capability to add activities in the course.
            if (!has_capability('moodle/course:manageactivities', $coursecontext)) {
                $logs[] = [
                    'type' => 'error',
                    'message' => get_string('error_nopermission_course', 'tool_bulkcohortsync', (object) [
                        'course' => format_string($c->fullname),
                    ]),
                ];
                continue;
            }

            $title = trim($data->{"title_{$cid}"} ?? '');
            $url = trim($data->{"url_{$cid}"} ?? '');
            $draftitemid = (int)($data->{"file_{$cid}"} ?? 0);

            $hasfile = false;
            if (!empty($draftitemid)) {
                $draftfiles = $fs->get_area_files($usercontext->id, 'user', 'draft', $draftitemid, 'id DESC', false);
                $hasfile = !empty($draftfiles);
            }

            // Skip if no file and no url provided for this course.
            if (!$hasfile && empty($url)) {
                continue;
            }

            // Ensure section 0 exists for the course.
            $cw = $DB->get_record('course_sections', ['course' => $cid, 'section' => 0]);
            if (!$cw) {
                course_create_sections_if_missing($cid, 0);
            }

            // Process File Upload (mod_resource).
            if ($hasfile && $modresource) {
                try {
                    $moduleinfo = new stdClass();
                    $moduleinfo->modulename = 'resource';
                    $moduleinfo->module = $modresource->id;
                    $moduleinfo->course = $cid;
                    $moduleinfo->section = 0;
                    $moduleinfo->visible = 1;
                    $moduleinfo->name = $title;
                    $moduleinfo->files = $draftitemid;

                    create_module($moduleinfo);

                    $logs[] = [
                        'type' => 'success',
                        'message' => get_string('success_resource_added', 'tool_bulkcohortsync', (object) [
                            'title' => $title,
                            'course' => format_string($c->fullname),
                        ]),
                    ];
                } catch (Exception $ex) {
                    $logs[] = [
                        'type' => 'error',
                        'message' => get_string('error_generic', 'tool_bulkcohortsync', (object) [
                            'course' => format_string($c->fullname),
                            'error' => $ex->getMessage(),
                        ]),
                    ];
                }
            }

            // Process URL Link (mod_url).
            if (!empty($url) && $modurl) {
                try {
                    $moduleinfo = new stdClass();
                    $moduleinfo->modulename = 'url';
                    $moduleinfo->module = $modurl->id;
                    $moduleinfo->course = $cid;
                    $moduleinfo->section = 0;
                    $moduleinfo->visible = 1;
                    $moduleinfo->name = $title . ($hasfile ? ' (Link)' : '');
                    $moduleinfo->externalurl = $url;
                    $moduleinfo->display = 0; // RESOURCELIB_DISPLAY_AUTO.

                    create_module($moduleinfo);

                    $logs[] = [
                        'type' => 'success',
                        'message' => get_string('success_url_added', 'tool_bulkcohortsync', (object) [
                            'title' => $moduleinfo->name,
                            'course' => format_string($c->fullname),
                        ]),
                    ];
                } catch (Exception $ex) {
                    $logs[] = [
                        'type' => 'error',
                        'message' => get_string('error_generic', 'tool_bulkcohortsync', (object) [
                            'course' => format_string($c->fullname),
                            'error' => $ex->getMessage(),
                        ]),
                    ];
                }
            }
        }
    }
}

echo $OUTPUT->header();
?>

<div class="tool-bulkcohortsync-container container-fluid mt-3">
    <!-- Top Navigation Tabs -->
    <ul class="nav nav-tabs nav-tabs-custom">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo new moodle_url('/admin/tool/bulkcohortsync/index.php'); ?>">
                <?php echo get_string('tab_cohortsync', 'tool_bulkcohortsync'); ?>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo new moodle_url('/admin/tool/bulkcohortsync/bulk_resources.php'); ?>">
                <?php echo get_string('tab_resources', 'tool_bulkcohortsync'); ?>
            </a>
        </li>
    </ul>

    <div class="row">
        <div class="col-12">
            <h2><?php echo get_string('tab_resources', 'tool_bulkcohortsync'); ?></h2>
            <p class="text-muted"><?php echo get_string('resources_desc', 'tool_bulkcohortsync'); ?></p>
        </div>
    </div>

    <?php if (!empty($logs)): ?>
    <div class="row">
        <div class="col-12">
            <div class="sync-card">
                <h4 class="sync-title"><?php echo get_string('executionlogs', 'tool_bulkcohortsync'); ?></h4>
                <div class="log-container">
                    <?php foreach ($logs as $log): ?>
                        <div class="log-line log-<?php echo s($log['type']); ?>">
                            [<?php echo s(core_text::strtoupper($log['type'])); ?>] <?php echo s($log['message']); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Step 1: Select Category Form -->
    <div class="sync-card">
        <form method="get" action="<?php echo new moodle_url('/admin/tool/bulkcohortsync/bulk_resources.php'); ?>">
            <div class="form-group mb-0 d-flex align-items-center flex-wrap gap-3">
                <label for="select-catid" class="font-weight-bold mb-0 mr-3"><?php echo get_string('selectcategory', 'tool_bulkcohortsync'); ?></label>
                <select id="select-catid" name="catid" class="form-control w-auto" onchange="this.form.submit()">
                    <option value="0"><?php echo get_string('choosecategory', 'tool_bulkcohortsync'); ?></option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat->id; ?>" <?php echo ($catid == $cat->id) ? 'selected' : ''; ?>>
                            <?php echo str_repeat('&nbsp;&nbsp;&nbsp;', max(0, $cat->depth - 1)) . format_string($cat->name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <noscript><button type="submit" class="btn btn-primary btn-sm"><?php echo get_string('submit'); ?></button></noscript>
            </div>
        </form>
    </div>

    <!-- Step 2: Display Courses in Selected Category with MoodleForm -->
    <?php if ($catid > 0): ?>
        <?php if (empty($coursesincat)): ?>
            <div class="alert alert-info">
                <?php echo get_string('nocoursesincat', 'tool_bulkcohortsync'); ?>
            </div>
        <?php else: ?>
            <div class="sync-card">
                <?php
                if ($mform) {
                    $mform->display();
                }
                ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php
echo $OUTPUT->footer();
