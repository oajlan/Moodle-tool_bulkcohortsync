# Bulk Cohort Course Sync (`tool_bulkcohortsync`)

A community administrator tool plugin for Moodle LMS that enables administrators and managers to quickly synchronise cohorts (batches) across multiple courses in bulk, and upload course materials in batches.

---

## Features

- **Bulk Cohort Synchronization**:
  - Select multiple courses across hierarchical category trees.
  - Select multiple cohorts at once.
  - Assign any course-valid role (e.g. Student, Teacher).
  - Real-time search filters for both courses and cohorts.
  - Expandable / collapsible category trees with course count badges.
  - Enforces all core Moodle cohort enrolment capability and context availability checks.
  - Prevents duplicate synchronisation instances.
- **Bulk Course Materials**:
  - Choose a course category (e.g. Semester or Department) to view all courses inside it.
  - Upload files (using Moodle's standard Form filepicker API) or attach URLs directly to multiple courses at once.
- **Command-Line Interface (CLI)**:
  - Run bulk synchronisation tasks from the server shell or automated cron jobs (`cli/sync.php`).
- **Modern Architecture**:
  - Fully implements Moodle's Privacy API (`null_provider`).
  - Responsive interface powered by Mustache templates and AMD JavaScript modules.
  - Multi-language support: English (`en`) and Arabic (`ar`).

---

## Requirements

- **Moodle**: 4.1 or newer (Build 2022112800+)
- **PHP**: 8.0, 8.1, 8.2+
- Core cohort enrolment plugin (`enrol_cohort`) must be enabled on your site.

---

## Installation

### Method 1: Via Moodle Plugins Directory (Recommended)
1. Log in to your Moodle site as an administrator.
2. Navigate to **Site administration > Plugins > Install plugins**.
3. Upload `tool_bulkcohortsync.zip` or install directly from the Moodle plugins directory.
4. Follow the on-screen instructions to finish the installation.

### Method 2: Manual Installation (Git / ZIP)
1. Download or clone this repository into your Moodle installation under the `admin/tool/bulkcohortsync` directory:
   ```bash
   git clone https://github.com/your-username/moodle-tool_bulkcohortsync.git admin/tool/bulkcohortsync
   ```
2. Visit **Site administration > Notifications** to complete the database upgrade.

---

## Usage

### 1. Web Interface
1. Go to **Site administration > Courses > Bulk Cohort Course Sync**.
2. **Bulk Cohort Sync Tab**:
   - Use the category tree on the left to select the target courses.
   - Use the cohort list on the right to select the cohorts.
   - Select the role to assign (default: Student).
   - Click **Sync Cohorts to Courses**.
   - Review the detailed execution log displayed on the screen.
3. **Bulk Course Materials Tab**:
   - Select a course category from the dropdown.
   - Enter a title, choose a file via the filepicker, or provide a URL for each course.
   - Click **Upload & Apply Materials in Bulk**.

### 2. Command-Line Interface (CLI)
You can execute synchronisation directly from the command line:
```bash
php admin/tool/bulkcohortsync/cli/sync.php --courses=CS101,CS102 --cohorts=Batch2026,Batch2027 --role=student
```

For help and all options:
```bash
php admin/tool/bulkcohortsync/cli/sync.php --help
```

---

## Privacy API

This plugin implements the Moodle Privacy API (`\core_privacy\local\metadata\null_provider`). It does not store or process any personal user data. It utilizes Moodle core's existing enrolment and course module subsystems.

---

## Public Issue Tracker

Please report any bugs, issues, or feature suggestions on our public tracker:
[https://github.com/your-username/moodle-tool_bulkcohortsync/issues](https://github.com/your-username/moodle-tool_bulkcohortsync/issues)

---

## License

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

See the [LICENSE](LICENSE) file for more details.
