<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Arabic language strings for tool_bulkcohortsync.
 *
 * @package    tool_bulkcohortsync
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'مزامنة الأفواج والمقررات بالجملة';
$string['privacy:metadata'] = 'أداة مزامنة الأفواج والمقررات بالجملة لا تخزن أي بيانات شخصية.';
$string['description'] = 'حدد عدة أفواج/زمر وقم بربطها ومزامنتها مع عدة مقررات دراسية فورياً باستخدام طريقة مزامنة الأفواج في مودل.';
$string['tab_cohortsync'] = 'مزامنة الأفواج بالمقررات';
$string['tab_resources'] = 'إضافة مواد ومحتوى للمقررات بالجملة';
$string['selectcourses'] = '1. اختر المقررات الدراسية';
$string['selectcohorts'] = '2. اختر الأفواج / الزمر';
$string['configureandexecute'] = '3. الإعداد والتنفيذ';
$string['searchcourses'] = 'بحث في المقررات...';
$string['searchcohorts'] = 'بحث في الأفواج...';
$string['selectall'] = 'تحديد الكل';
$string['deselectall'] = 'إلغاء تحديد الكل';
$string['selected'] = 'محدد';
$string['selectrole'] = 'اختر الدور المراد إسناده:';
$string['syncbtn'] = 'بدء مزامنة الأفواج مع المقررات';
$string['executionlogs'] = 'سجل التنفيذ والعمليات';
$string['error_selectboth'] = 'يرجى تحديد مقرر واحد على الأقل وفوج واحد على الأقل.';
$string['error_noplugin'] = 'إضافة تسجيل الأفواج (enrol_cohort) غير متوفرة أو معطلة في النظام.';
$string['error_nopermission_course'] = 'ليس لديك صلاحية إدارة التسجيل في المقرر \'{$a->course}\'.';
$string['error_cohortnotavailable'] = 'الفوج \'{$a->cohort}\' غير متاح في سياق المقرر \'{$a->course}\'.';
$string['error_invalidrole'] = 'الدور المحدد لا يمكن إسناده في المقرر \'{$a->course}\'.';
$string['error_generic'] = 'خطأ في المقرر \'{$a->course}\': {$a->error}';
$string['info_alreadysynced'] = 'الفوج \'{$a->cohort}\' مرتبط بالفعل مسبقاً بالمقرر \'{$a->course}\'.';
$string['success_synced'] = 'تمت مزامنة الفوج \'{$a->cohort}\' (الرمز: {$a->idnumber}) بنجاح مع المقرر \'{$a->course}\'.';
$string['error_failed'] = 'فشلت مزامنة الفوج \'{$a->cohort}\' مع المقرر \'{$a->course}\'.';

// Bulk Resources strings.
$string['resources_desc'] = 'اختر تصنيفاً (مثل الفصل الدراسي أو القسم) لعرض كافة المقررات الدراسية التابعة له ورفع الملفات أو ربط الروابط بالجملة.';
$string['selectcategory'] = 'اختر التصنيف:';
$string['choosecategory'] = '-- اختر التصنيف --';
$string['coursename'] = 'اسم المقرر';
$string['materialtitle'] = 'عنوان المادة / المحتوى';
$string['uploadfile'] = 'رفع ملف';
$string['urllink'] = 'رابط URL';
$string['uploadbtn'] = 'رفع وتطبيق المحتوى والمواد بالجملة';
$string['nocoursesincat'] = 'لا توجد مقررات دراسية في التصنيف المحدد.';
$string['success_resource_added'] = 'تم إضافة ملف المحتوى \'{$a->title}\' بنجاح للمقرر \'{$a->course}\'.';
$string['success_url_added'] = 'تم إضافة الرابط \'{$a->title}\' بنجاح للمقرر \'{$a->course}\'.';
$string['error_notitle'] = 'عنوان المحتوى مطلوب عند اختيار ملف أو رابط للمقرر \'{$a->course}\'.';
