<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Moodle form for bulk course resources upload.
 *
 * @package    tool_bulkcohortsync
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace tool_bulkcohortsync\form;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

/**
 * Form for uploading materials and links to courses in bulk.
 *
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class bulk_resources_form extends \moodleform {

    /**
     * Form definition.
     */
    protected function definition() {
        $mform = $this->_form;
        $courses = $this->_customdata['courses'] ?? [];
        $catid = $this->_customdata['catid'] ?? 0;

        $mform->addElement('hidden', 'catid', $catid);
        $mform->setType('catid', PARAM_INT);

        foreach ($courses as $c) {
            $mform->addElement('header', 'hdr_' . $c->id, format_string($c->fullname) . ' (' . s($c->shortname) . ')');

            $mform->addElement('text', 'title_' . $c->id, get_string('materialtitle', 'tool_bulkcohortsync'));
            $mform->setType('title_' . $c->id, PARAM_TEXT);

            $mform->addElement('filepicker', 'file_' . $c->id, get_string('uploadfile', 'tool_bulkcohortsync'), null, [
                'maxbytes' => 0,
                'accepted_types' => '*',
            ]);

            $mform->addElement('url', 'url_' . $c->id, get_string('urllink', 'tool_bulkcohortsync'));
            $mform->setType('url_' . $c->id, PARAM_URL);
        }

        $this->add_action_buttons(false, get_string('uploadbtn', 'tool_bulkcohortsync'));
    }

    /**
     * Validate form data.
     *
     * @param array $data Submitted data.
     * @param array $files Uploaded files.
     * @return array Errors array.
     */
    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        $courses = $this->_customdata['courses'] ?? [];

        foreach ($courses as $c) {
            $cid = $c->id;
            $title = trim($data['title_' . $cid] ?? '');
            $url = trim($data['url_' . $cid] ?? '');
            $draftitemid = $data['file_' . $cid] ?? 0;

            // Check if draft area has any files.
            $hasfile = false;
            if (!empty($draftitemid)) {
                $usercontext = \context_user::instance($GLOBALS['USER']->id);
                $fs = get_file_storage();
                $files = $fs->get_area_files($usercontext->id, 'user', 'draft', $draftitemid, 'id DESC', false);
                $hasfile = !empty($files);
            }

            if (($hasfile || !empty($url)) && empty($title)) {
                $errors['title_' . $cid] = get_string('error_notitle', 'tool_bulkcohortsync', (object) [
                    'course' => format_string($c->fullname),
                ]);
            }
        }

        return $errors;
    }
}
