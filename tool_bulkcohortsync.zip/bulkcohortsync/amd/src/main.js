// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * JavaScript module for tool_bulkcohortsync.
 *
 * @module     tool_bulkcohortsync/main
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['core/str'], function(str) {
    'use strict';

    return {
        /**
         * Initialize the bulk cohort sync interface.
         *
         * @param {String} selectedStr Translated string for 'selected'.
         */
        init: function(selectedStr) {
            var labelSelected = selectedStr || 'Selected';

            // 1. Category collapse/expand (manual click only).
            var headers = document.querySelectorAll('.cat-header');
            headers.forEach(function(header) {
                header.addEventListener('click', function(e) {
                    if (e.target.classList.contains('cat-select-link')) {
                        return;
                    }
                    var catid = this.getAttribute('data-catid');
                    var body = document.getElementById('cat-body-' + catid);
                    if (body) {
                        if (body.classList.contains('hidden')) {
                            body.classList.remove('hidden');
                            this.classList.remove('collapsed');
                        } else {
                            body.classList.add('hidden');
                            this.classList.add('collapsed');
                        }
                    }
                });
            });

            // 2. Per-category select/deselect links.
            var selectLinks = document.querySelectorAll('.cat-select-link');
            selectLinks.forEach(function(link) {
                link.addEventListener('click', function(e) {
                    e.stopPropagation();
                    var catid = this.getAttribute('data-catid');
                    var action = this.getAttribute('data-action');
                    var container = document.getElementById('cat-body-' + catid);
                    if (container) {
                        var checkboxes = container.querySelectorAll('.course-checkbox');
                        checkboxes.forEach(function(cb) {
                            cb.checked = (action === 'select');
                        });
                    }
                    updateCoursesCounter();
                });
            });

            // 3. Search filter for Courses (preserves collapsed state).
            var courseSearch = document.getElementById('course-search');
            if (courseSearch) {
                courseSearch.addEventListener('input', function() {
                    var query = this.value.toLowerCase().trim();
                    var groups = document.querySelectorAll('.cat-group');
                    groups.forEach(function(group) {
                        var items = group.querySelectorAll('.course-item');
                        var anyVisible = false;
                        items.forEach(function(item) {
                            var name = item.getAttribute('data-name') || '';
                            var show = name.indexOf(query) !== -1;
                            item.style.display = show ? 'flex' : 'none';
                            if (show) {
                                anyVisible = true;
                            }
                        });
                        group.style.display = (query === '' || anyVisible) ? '' : 'none';
                    });
                });
            }

            // 4. Search filter for Cohorts.
            var cohortSearch = document.getElementById('cohort-search');
            if (cohortSearch) {
                cohortSearch.addEventListener('input', function() {
                    var query = this.value.toLowerCase().trim();
                    var items = document.querySelectorAll('.cohort-item');
                    items.forEach(function(item) {
                        var name = item.getAttribute('data-name') || '';
                        item.style.display = (name.indexOf(query) !== -1) ? 'flex' : 'none';
                    });
                });
            }

            // 5. Counters.
            var coursesCounter = document.getElementById('courses-counter');
            var cohortsCounter = document.getElementById('cohorts-counter');
            var courseCheckboxes = document.querySelectorAll('.course-checkbox');
            var cohortCheckboxes = document.querySelectorAll('.cohort-checkbox');

            function updateCoursesCounter() {
                if (coursesCounter) {
                    var checkedCount = document.querySelectorAll('.course-checkbox:checked').length;
                    coursesCounter.textContent = checkedCount + ' ' + labelSelected;
                }
            }

            function updateCohortsCounter() {
                if (cohortsCounter) {
                    var checkedCount = document.querySelectorAll('.cohort-checkbox:checked').length;
                    cohortsCounter.textContent = checkedCount + ' ' + labelSelected;
                }
            }

            courseCheckboxes.forEach(function(cb) {
                cb.addEventListener('change', updateCoursesCounter);
            });
            cohortCheckboxes.forEach(function(cb) {
                cb.addEventListener('change', updateCohortsCounter);
            });

            // 6. Global Select All / Deselect All.
            var selAllCourses = document.getElementById('select-all-courses');
            if (selAllCourses) {
                selAllCourses.addEventListener('click', function(e) {
                    e.preventDefault();
                    courseCheckboxes.forEach(function(cb) {
                        var parentItem = cb.closest('.course-item');
                        if (!parentItem || parentItem.style.display !== 'none') {
                            cb.checked = true;
                        }
                    });
                    updateCoursesCounter();
                });
            }

            var deselAllCourses = document.getElementById('deselect-all-courses');
            if (deselAllCourses) {
                deselAllCourses.addEventListener('click', function(e) {
                    e.preventDefault();
                    courseCheckboxes.forEach(function(cb) {
                        cb.checked = false;
                    });
                    updateCoursesCounter();
                });
            }

            var selAllCohorts = document.getElementById('select-all-cohorts');
            if (selAllCohorts) {
                selAllCohorts.addEventListener('click', function(e) {
                    e.preventDefault();
                    cohortCheckboxes.forEach(function(cb) {
                        var parentItem = cb.closest('.cohort-item');
                        if (!parentItem || parentItem.style.display !== 'none') {
                            cb.checked = true;
                        }
                    });
                    updateCohortsCounter();
                });
            }

            var deselAllCohorts = document.getElementById('deselect-all-cohorts');
            if (deselAllCohorts) {
                deselAllCohorts.addEventListener('click', function(e) {
                    e.preventDefault();
                    cohortCheckboxes.forEach(function(cb) {
                        cb.checked = false;
                    });
                    updateCohortsCounter();
                });
            }
        }
    };
});
