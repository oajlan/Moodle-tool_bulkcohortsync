<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Helper class for tool_bulkcohortsync.
 *
 * @package    tool_bulkcohortsync
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace tool_bulkcohortsync;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/cohort/lib.php');
require_once($CFG->dirroot . '/enrol/cohort/lib.php');

/**
 * Helper utilities for tool_bulkcohortsync.
 *
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class helper {

    /**
     * Build the category tree with courses assigned to each node.
     *
     * @return array Array of root category tree nodes.
     */
    public static function get_category_tree(): array {
        global $DB;

        $allcategories = $DB->get_records('course_categories', null, 'sortorder ASC', 'id, name, parent, depth, path');
        $allcourses = $DB->get_records_select('course', "format <> 'site'", null, 'fullname ASC', 'id, fullname, shortname, category');

        $catnodes = [];
        foreach ($allcategories as $cat) {
            $catnodes[$cat->id] = (object) [
                'id' => $cat->id,
                'name' => format_string($cat->name),
                'parent' => $cat->parent,
                'depth' => $cat->depth,
                'children' => [],
                'courses' => [],
            ];
        }

        $uncatname = get_string('defaultcategoryname');
        foreach ($allcourses as $c) {
            if (isset($catnodes[$c->category])) {
                $catnodes[$c->category]->courses[] = $c;
            } else {
                if (!isset($catnodes[0])) {
                    $catnodes[0] = (object) [
                        'id' => 0,
                        'name' => $uncatname,
                        'parent' => 0,
                        'depth' => 1,
                        'children' => [],
                        'courses' => [],
                    ];
                }
                $catnodes[0]->courses[] = $c;
            }
        }

        $tree = [];
        foreach ($catnodes as $node) {
            if ($node->parent != 0 && isset($catnodes[$node->parent])) {
                $catnodes[$node->parent]->children[] = $node;
            } else {
                $tree[] = $node;
            }
        }

        return $tree;
    }

    /**
     * Calculate total course count for a category node and all its children.
     *
     * @param object $node Category node.
     * @return int Total course count.
     */
    public static function get_subtree_course_count(object $node): int {
        $count = count($node->courses);
        foreach ($node->children as $child) {
            $count += self::get_subtree_course_count($child);
        }
        return $count;
    }

    /**
     * Export category tree nodes into array suitable for Mustache templates.
     *
     * @param array $nodes Category nodes.
     * @return array Exported nodes.
     */
    public static function export_category_tree_for_template(array $nodes): array {
        $result = [];

        foreach ($nodes as $node) {
            $totalcourses = self::get_subtree_course_count($node);
            if ($totalcourses === 0) {
                continue;
            }

            $coursesdata = [];
            foreach ($node->courses as $c) {
                $coursesdata[] = [
                    'id' => $c->id,
                    'fullname' => format_string($c->fullname),
                    'shortname' => s($c->shortname),
                    'searchname' => s(core_text::strtolower($c->fullname . ' ' . $c->shortname)),
                ];
            }

            $childrendata = !empty($node->children) ? self::export_category_tree_for_template($node->children) : [];

            $result[] = [
                'id' => $node->id,
                'name' => $node->name,
                'depth' => $node->depth,
                'totalcourses' => $totalcourses,
                'hascourses' => !empty($coursesdata),
                'courses' => $coursesdata,
                'haschildren' => !empty($childrendata),
                'children' => $childrendata,
            ];
        }

        return $result;
    }

    /**
     * Apply the cohort enrolment checks that the core form applies.
     *
     * @param object $course The course record.
     * @param object $cohort The cohort record.
     * @param int $roleid The role ID to assign.
     * @return array Array with keys: 'valid' (bool), 'error' (string, empty if valid).
     */
    public static function validate_cohort_enrolment(object $course, object $cohort, int $roleid): array {
        global $DB;

        $enrolplugin = enrol_get_plugin('cohort');
        if (!$enrolplugin || !enrol_is_enabled('cohort')) {
            return [
                'valid' => false,
                'error' => get_string('error_noplugin', 'tool_bulkcohortsync'),
            ];
        }

        $coursecontext = \context_course::instance($course->id);

        // 1. Permission checks applied by core cohort enrolment form.
        if (!$enrolplugin->can_add_instance($course->id)) {
            return [
                'valid' => false,
                'error' => get_string('error_nopermission_course', 'tool_bulkcohortsync', (object) [
                    'course' => format_string($course->fullname),
                ]),
            ];
        }

        // 2. Check if cohort is available to this course's context.
        $availablecohorts = cohort_get_available_cohorts($coursecontext, 0, 0, 0);
        $availablecohortids = array_map(function($c) {
            return (int)$c->id;
        }, $availablecohorts);

        if (!in_array((int)$cohort->id, $availablecohortids, true)) {
            return [
                'valid' => false,
                'error' => get_string('error_cohortnotavailable', 'tool_bulkcohortsync', (object) [
                    'cohort' => format_string($cohort->name),
                    'course' => format_string($course->fullname),
                ]),
            ];
        }

        // 3. Check role assignability in course context.
        $assignableroles = get_assignable_roles($coursecontext, ROLENAME_BOTH);
        if ($roleid != 0 && !array_key_exists($roleid, $assignableroles)) {
            return [
                'valid' => false,
                'error' => get_string('error_invalidrole', 'tool_bulkcohortsync', (object) [
                    'course' => format_string($course->fullname),
                ]),
            ];
        }

        // 4. Check if instance already exists.
        $params = [
            'enrol' => 'cohort',
            'courseid' => $course->id,
            'customint1' => $cohort->id,
        ];
        if ($DB->record_exists('enrol', $params)) {
            return [
                'valid' => false,
                'alreadysynced' => true,
                'error' => get_string('info_alreadysynced', 'tool_bulkcohortsync', (object) [
                    'cohort' => format_string($cohort->name),
                    'course' => format_string($course->fullname),
                ]),
            ];
        }

        return ['valid' => true, 'error' => ''];
    }

    /**
     * Add a cohort enrolment instance to a course with full core validation checks.
     *
     * @param object $course The course record.
     * @param object $cohort The cohort record.
     * @param int $roleid The role ID.
     * @return array Result array with status ('success', 'info', 'error') and message.
     */
    public static function add_cohort_sync_instance(object $course, object $cohort, int $roleid): array {
        $validation = self::validate_cohort_enrolment($course, $cohort, $roleid);
        if (!$validation['valid']) {
            if (!empty($validation['alreadysynced'])) {
                return ['type' => 'info', 'message' => $validation['error']];
            }
            return ['type' => 'error', 'message' => $validation['error']];
        }

        $enrolplugin = enrol_get_plugin('cohort');
        $fields = [
            'customint1' => $cohort->id,
            'roleid' => $roleid,
            'status' => ENROL_INSTANCE_ENABLED,
        ];

        $instanceid = $enrolplugin->add_instance($course, $fields);
        if ($instanceid) {
            return [
                'type' => 'success',
                'message' => get_string('success_synced', 'tool_bulkcohortsync', (object) [
                    'cohort' => format_string($cohort->name),
                    'idnumber' => s($cohort->idnumber),
                    'course' => format_string($course->fullname),
                ]),
            ];
        }

        return [
            'type' => 'error',
            'message' => get_string('error_failed', 'tool_bulkcohortsync', (object) [
                'cohort' => format_string($cohort->name),
                'course' => format_string($course->fullname),
            ]),
        ];
    }
}
