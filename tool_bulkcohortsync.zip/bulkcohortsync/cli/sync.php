<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * CLI script to bulk sync cohorts to courses.
 *
 * @package    tool_bulkcohortsync
 * @subpackage cli
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('CLI_SCRIPT', true);

require(__DIR__ . '/../../../../config.php');
require_once($CFG->libdir . '/clilib.php');

$longparams = [
    'help' => false,
    'courses' => '',
    'cohorts' => '',
    'role' => 'student',
];

$shortparams = [
    'h' => 'help',
];

list($options, $unrecognized) = cli_get_params($longparams, $shortparams);

if ($unrecognized) {
    $unrecognized = implode("\n  ", $unrecognized);
    cli_error(get_string('cliunknowoption', 'admin', $unrecognized));
}

if ($options['help'] || empty($options['courses']) || empty($options['cohorts'])) {
    $help = "Bulk Cohort Sync CLI Tool

Options:
-h, --help            Print out this help
--courses=C1,C2...    Comma-separated list of course shortnames or course IDs.
--cohorts=CO1,CO2...  Comma-separated list of cohort idnumbers, names, or IDs.
--role=student        Role shortname (default: student).

Example:
php admin/tool/bulkcohortsync/cli/sync.php --courses=CS_2026,CS_AI_101 --cohorts=32-27,32-28
";
    cli_writeln($help);
    exit(0);
}

// Resolve role.
$roleshortname = $options['role'];
$role = $DB->get_record('role', ['shortname' => $roleshortname]);
if (!$role) {
    cli_error("Error: Role '$roleshortname' not found.");
}

// Resolve courses.
$coursesinput = explode(',', $options['courses']);
$courses = [];
foreach ($coursesinput as $ci) {
    $ci = trim($ci);
    if (empty($ci)) {
        continue;
    }
    $c = is_numeric($ci) ? $DB->get_record('course', ['id' => $ci]) : $DB->get_record('course', ['shortname' => $ci]);
    if ($c) {
        $courses[] = $c;
    } else {
        cli_writeln("Warning: Course '$ci' not found. Skipping.");
    }
}

// Resolve cohorts.
$cohortsinput = explode(',', $options['cohorts']);
$cohorts = [];
foreach ($cohortsinput as $ch) {
    $ch = trim($ch);
    if (empty($ch)) {
        continue;
    }
    if (is_numeric($ch)) {
        $cohort = $DB->get_record('cohort', ['id' => $ch]);
    } else {
        $cohort = $DB->get_record('cohort', ['idnumber' => $ch]);
        if (!$cohort) {
            $cohort = $DB->get_record('cohort', ['name' => $ch]);
        }
    }
    if ($cohort) {
        $cohorts[] = $cohort;
    } else {
        cli_writeln("Warning: Cohort '$ch' not found. Skipping.");
    }
}

if (empty($courses)) {
    cli_error("Error: No valid courses resolved.");
}
if (empty($cohorts)) {
    cli_error("Error: No valid cohorts resolved.");
}

foreach ($courses as $course) {
    foreach ($cohorts as $cohort) {
        $res = \tool_bulkcohortsync\helper::add_cohort_sync_instance($course, $cohort, (int)$role->id);
        cli_writeln(ucfirst($res['type']) . ": " . $res['message']);
    }
}

cli_writeln("Bulk sync completed.");
exit(0);
